SAVANNA BREW CAFE WEBSITE
=========================

Project files:
- index.html: Home page
- about.html: About Us page
- menu.html: Menu page with three tables
- gallery.html: Responsive photo gallery
- contact.html: Contact information, opening hours and reservation form
- css/style.css: Shared external stylesheet
- images/: Image assets and placeholders

HOW TO RUN
1. Extract the project ZIP file.
2. Open the savanna-brew folder.
3. Double-click index.html to open the site in a web browser.
4. Use the navigation links to visit all five pages.

IMAGE NOTES
The images folder includes locally generated SVG illustrations saved with .jpg filenames so that the pages show visual placeholders immediately. For a real submission, replace them with genuine, appropriately licensed JPEG or PNG photos and keep the same filenames. Check that the images have suitable alt text in the HTML.

FORM NOTE
The reservation form uses a mailto action as a simple HTML-only demonstration. It requires a configured email application and does not store bookings on a server.

VALIDATION
Validate each HTML file at https://validator.w3.org/ and css/style.css at https://jigsaw.w3.org/css-validator/.
Do not claim validation has passed until you have run the validators. Record any remaining warnings here:
[Add validation results after testing.]

PHOTO UPDATE
The homepage, About page, and gallery now use café photographs hosted by Unsplash. An internet connection is needed for these photos to load. The image files in the images folder remain as local placeholders and can be replaced with your own café photographs if required.
